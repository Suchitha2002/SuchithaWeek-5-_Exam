﻿using System.Data.Entity;
using WebAPIAssessment.Entities;
using static WebAPIAssessment.Repository.IAsyncRepository;

namespace WebAPIAssessment.Repository
{
    public class ItemRepository : IItemAsyncRepository
    {
        private readonly PODbContext _context;
        public ItemRepository(PODbContext pODbContext)
        {
            _context = pODbContext;
        }
        public async Task Add(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var item = await _context.Items.FindAsync(id);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Item>> GetAllAsync()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetById(string id)
        {
            return await _context.Items.SingleOrDefaultAsync(i => i.ItCode == id);
        }

        public async Task Update(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }
    }
}