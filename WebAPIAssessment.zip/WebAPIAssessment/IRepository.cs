﻿namespace WebAPIAssessment
{
    internal interface IRepository
    {
    }
}