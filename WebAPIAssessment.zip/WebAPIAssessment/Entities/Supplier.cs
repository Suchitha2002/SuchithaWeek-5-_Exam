﻿using System.ComponentModel.DataAnnotations;

namespace WebAPIAssessment.Entities
{
    public class Supplier
    {
        [Key]
        public string SupplierNo { get; set; }
        [Required]
        [MaxLength(15)]
        public string SupplierName { get; set; }
        [MaxLength(10)]
        public string Address { get; set; }
    }
}