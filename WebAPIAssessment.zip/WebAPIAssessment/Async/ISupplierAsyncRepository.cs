﻿using WebAPIAssessment.Entities;

namespace WebAPIAssessment.Async
{
    public interface ISupplierAsyncRepository
    {
        Task<List<Supplier>> GetAllAsync();
        Task<Supplier> GetById(string id);
        Task Update(Supplier supplier);
        Task DeleteById(string id);
        Task Add(Supplier supplier);
    }

}
